# WexatP2P — Production Foundation

WexatP2P is a production-oriented ETB/USD P2P marketplace foundation.

## Important
This repository is **not a fake demo**: it contains a real API/domain model, PostgreSQL schema, authentication structure, ledger model, KYC/trade/dispute state machines, audit logging, idempotency support, and provider interfaces.

It is **not yet legally/live-money operational** by itself. Real ETB/USD settlement requires:
1. Appropriate Ethiopian regulatory authorization / licensed operating structure.
2. A contracted, authorized payment/settlement provider.
3. A real KYC/identity provider and approved compliance process.
4. Production secrets, domain, TLS, monitoring, backups and security review.
5. Provider webhook credentials and tested settlement flows.

Never put KYC documents, API secrets, private keys, or production database credentials in Git.

## Stack
- Web: Next.js + TypeScript
- API: Node.js + Fastify + TypeScript
- Database: PostgreSQL + Prisma
- Cache/locks: Redis (adapter-ready)
- Auth: Argon2 password hashing + server sessions
- Validation: Zod
- Architecture: provider adapters + domain services + immutable ledger + audit events

## Monorepo
apps/web       Next.js user/admin UI
apps/api       Fastify API
packages/db    Prisma schema/client
packages/core  shared domain types
infra           Docker Compose for local infrastructure

## Run
1. Copy `.env.example` to `.env`.
2. Start PostgreSQL/Redis:
   docker compose -f infra/docker-compose.yml up -d
3. Install:
   npm install
4. Generate Prisma client:
   npm run db:generate
5. Run migration:
   npm run db:migrate
6. Start API and web:
   npm run dev

Production deployment should use managed PostgreSQL/Redis, secret management, HTTPS, WAF/rate limiting, backups, alerting and independent security testing.

## Real integrations
The API exposes provider interfaces for:
- KYC verification
- payment collection/status
- settlement
- notifications

Provider adapters must be implemented with the credentials and contracts of the actual licensed providers selected for launch. The default implementation fails closed instead of pretending a payment or KYC check succeeded.
