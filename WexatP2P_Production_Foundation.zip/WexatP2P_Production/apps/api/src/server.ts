import Fastify from "fastify";
import cors from "@fastify/cors";
import cookie from "@fastify/cookie";
import rateLimit from "@fastify/rate-limit";
import argon2 from "argon2";
import crypto from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { registerSchema, loginSchema, createOfferSchema, createTradeSchema } from "@wexat/core/src";

const db = new PrismaClient();
const app = Fastify({ logger: true });

const SESSION_COOKIE = "wexat_session";

function hashIp(ip?: string) {
  return crypto.createHash("sha256").update(ip ?? "").digest("hex");
}

async function audit(actorId: string | undefined, action: string, entityType: string, entityId: string, metadata: unknown, ip?: string) {
  await db.auditEvent.create({
    data: { actorId, action, entityType, entityId, metadata: metadata as any, ipHash: hashIp(ip) }
  });
}

async function requireUser(req: any, reply: any) {
  const sid = req.cookies[SESSION_COOKIE];
  if (!sid) return reply.code(401).send({ error: "Authentication required" });
  const session = await db.session.findUnique({ where: { id: sid }, include: { user: true } });
  if (!session || session.expiresAt <= new Date() || session.user.status !== "ACTIVE") {
    return reply.code(401).send({ error: "Session expired" });
  }
  req.user = session.user;
}

app.register(cors, { origin: process.env.WEB_ORIGIN ?? "http://localhost:3000", credentials: true });
app.register(cookie);
app.register(rateLimit, { max: 120, timeWindow: "1 minute" });

app.get("/health", async () => ({ ok: true, service: "wexat-api", time: new Date().toISOString() }));

app.post("/auth/register", async (req, reply) => {
  const input = registerSchema.parse(req.body);
  const exists = await db.user.findUnique({ where: { email: input.email.toLowerCase() } });
  if (exists) return reply.code(409).send({ error: "Account already exists" });

  const passwordHash = await argon2.hash(input.password, { type: argon2.argon2id });
  const user = await db.user.create({
    data: {
      email: input.email.toLowerCase(),
      phone: input.phone,
      passwordHash,
      profile: { create: {} },
      wallets: { create: [{ currency: "ETB" }, { currency: "USD" }] }
    },
    select: { id: true, email: true, status: true, kycStatus: true }
  });
  await audit(user.id, "USER_REGISTERED", "User", user.id, {}, req.ip);
  return reply.code(201).send({ user });
});

app.post("/auth/login", async (req, reply) => {
  const input = loginSchema.parse(req.body);
  const user = await db.user.findUnique({ where: { email: input.email.toLowerCase() } });
  if (!user || user.status !== "ACTIVE" || !(await argon2.verify(user.passwordHash, input.password))) {
    return reply.code(401).send({ error: "Invalid credentials" });
  }
  const sid = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + Number(process.env.SESSION_TTL_HOURS ?? 24) * 3600_000);
  await db.session.create({ data: { id: sid, userId: user.id, expiresAt, ipHash: hashIp(req.ip), userAgent: req.headers["user-agent"] } });
  reply.setCookie(SESSION_COOKIE, sid, {
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === "true",
    sameSite: "lax",
    path: "/",
    expires: expiresAt
  });
  await audit(user.id, "LOGIN", "User", user.id, {}, req.ip);
  return { user: { id: user.id, email: user.email, kycStatus: user.kycStatus } };
});

app.post("/auth/logout", { preHandler: requireUser }, async (req: any, reply) => {
  const sid = req.cookies[SESSION_COOKIE];
  if (sid) await db.session.deleteMany({ where: { id: sid } });
  reply.clearCookie(SESSION_COOKIE, { path: "/" });
  return { ok: true };
});

app.get("/me", { preHandler: requireUser }, async (req: any) => {
  return db.user.findUnique({
    where: { id: req.user.id },
    select: { id: true, email: true, phone: true, status: true, kycStatus: true, profile: true }
  });
});

app.get("/offers", async (req: any) => {
  const q = req.query as any;
  return db.offer.findMany({
    where: {
      status: "ACTIVE",
      ...(q.side ? { side: q.side } : {})
    },
    include: { user: { select: { id: true, profile: true, kycStatus: true } } },
    orderBy: { rateEtbPerUsd: "asc" },
    take: 100
  });
});

app.post("/offers", { preHandler: requireUser }, async (req: any, reply) => {
  if (req.user.kycStatus !== "VERIFIED") return reply.code(403).send({ error: "Verified KYC is required before trading" });
  const input = createOfferSchema.parse(req.body);
  const offer = await db.offer.create({
    data: {
      userId: req.user.id,
      side: input.side,
      rateEtbPerUsd: input.rateEtbPerUsd,
      availableUsd: input.availableUsd,
      minUsd: input.minUsd,
      maxUsd: input.maxUsd,
      paymentMethods: input.paymentMethods
    }
  });
  await audit(req.user.id, "OFFER_CREATED", "Offer", offer.id, { side: offer.side }, req.ip);
  return reply.code(201).send(offer);
});

app.post("/trades", { preHandler: requireUser }, async (req: any, reply) => {
  if (req.user.kycStatus !== "VERIFIED") return reply.code(403).send({ error: "Verified KYC is required before trading" });
  const input = createTradeSchema.parse(req.body);

  const trade = await db.$transaction(async tx => {
    const offer = await tx.offer.findUnique({ where: { id: input.offerId } });
    if (!offer || offer.status !== "ACTIVE") throw new Error("Offer unavailable");
    if (offer.userId === req.user.id) throw new Error("Cannot trade against your own offer");
    if (input.usdAmount < Number(offer.minUsd) || input.usdAmount > Number(offer.maxUsd) || input.usdAmount > Number(offer.availableUsd)) {
      throw new Error("Amount outside offer limits");
    }
    const buyerId = offer.side === "SELL_USD" ? req.user.id : offer.userId;
    const sellerId = offer.side === "SELL_USD" ? offer.userId : req.user.id;
    const etbAmount = input.usdAmount * Number(offer.rateEtbPerUsd);
    const updated = await tx.offer.updateMany({
      where: { id: offer.id, status: "ACTIVE", availableUsd: { gte: input.usdAmount } },
      data: { availableUsd: { decrement: input.usdAmount } }
    });
    if (updated.count !== 1) throw new Error("Offer inventory changed; retry");
    return tx.trade.create({
      data: {
        offerId: offer.id,
        buyerId,
        sellerId,
        usdAmount: input.usdAmount,
        etbAmount,
        rateEtbPerUsd: offer.rateEtbPerUsd,
        expiresAt: new Date(Date.now() + 30 * 60_000)
      }
    });
  }).catch(e => null);

  if (!trade) return reply.code(409).send({ error: "Trade could not be created" });
  await audit(req.user.id, "TRADE_CREATED", "Trade", trade.id, {}, req.ip);
  return reply.code(201).send(trade);
});

app.get("/trades/:id", { preHandler: requireUser }, async (req: any, reply) => {
  const trade = await db.trade.findUnique({
    where: { id: req.params.id },
    include: { offer: true, payments: true, messages: { orderBy: { createdAt: "asc" } }, disputes: true }
  });
  if (!trade || (trade.buyerId !== req.user.id && trade.sellerId !== req.user.id)) return reply.code(404).send({ error: "Trade not found" });
  return trade;
});

app.post("/trades/:id/report-payment", { preHandler: requireUser }, async (req: any, reply) => {
  const trade = await db.trade.findUnique({ where: { id: req.params.id } });
  if (!trade || trade.buyerId !== req.user.id || trade.status !== "OPEN") return reply.code(409).send({ error: "Trade is not awaiting payment" });
  const provider = process.env.PAYMENT_PROVIDER ?? "none";
  if (provider === "none") return reply.code(503).send({ error: "No real payment provider is configured" });
  return reply.code(501).send({ error: "Provider adapter must verify payment server-side before status changes" });
});

app.setErrorHandler((err, _req, reply) => {
  app.log.error(err);
  if ((err as any).name === "ZodError") return reply.code(400).send({ error: "Invalid request", details: (err as any).issues });
  return reply.code(500).send({ error: "Internal server error" });
});

app.listen({ port: Number(process.env.API_PORT ?? 4000), host: "0.0.0.0" });
