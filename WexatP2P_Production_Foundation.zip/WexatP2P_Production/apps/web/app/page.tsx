const api = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

export default async function Home() {
  let offers: any[] = [];
  try {
    const r = await fetch(`${api}/offers`, { cache: "no-store" });
    if (r.ok) offers = await r.json();
  } catch {}

  return (
    <main className="shell">
      <nav className="nav">
        <div className="brand">Wexat<span>P2P</span></div>
        <div className="pill">ETB ↔ USD</div>
      </nav>

      <section className="hero">
        <div>
          <span className="badge">ETHIOPIA • P2P FX</span>
          <h1>Trade Direct.<br/><span className="green">Trade Secure.</span></h1>
          <p>WexatP2P connects verified traders for direct ETB/USD offers, protected trade workflows, transparent records and professional account security.</p>
          <a className="cta" href="/register">Create account</a>
        </div>
        <div className="card">
          <div className="muted">Live marketplace</div>
          <div className="rate">{offers.length}<span className="muted" style={{fontSize:18}}> active offers</span></div>
          <p className="muted">Rates and availability come from the server-side marketplace API.</p>
          <div className="grid">
            <div><b>KYC</b><br/><span className="muted">Required</span></div>
            <div><b>Ledger</b><br/><span className="muted">Audited</span></div>
            <div><b>Disputes</b><br/><span className="muted">Supported</span></div>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Why WexatP2P</h2>
        <div className="grid">
          <div className="card"><h3>Verified traders</h3><p className="muted">Trading is gated by server-side KYC status.</p></div>
          <div className="card"><h3>Real records</h3><p className="muted">Trades, payments and ledger events are persisted in PostgreSQL.</p></div>
          <div className="card"><h3>Protected operations</h3><p className="muted">Authentication, rate limits, audit events and provider verification are built into the architecture.</p></div>
        </div>
      </section>

      <footer className="footer">WexatP2P • Production foundation • ETB/USD</footer>
    </main>
  );
}
