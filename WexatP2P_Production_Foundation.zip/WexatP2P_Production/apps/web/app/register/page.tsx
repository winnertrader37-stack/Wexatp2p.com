export default function Register() {
  return (
    <main className="shell"><style>{`input{width:100%;padding:13px;border-radius:12px;border:1px solid #26334d;background:#070c17;color:#fff;margin-top:7px}button{border:0;padding:13px 18px;border-radius:12px;background:#5ee6a8;font-weight:800;cursor:pointer}`}</style>
      <nav className="nav"><a className="brand" href="/">Wexat<span style={{color:"#5ee6a8"}}>P2P</span></a></nav>
      <div className="card" style={{maxWidth:520,margin:"70px auto"}}>
        <h1>Create your WexatP2P account</h1>
        <p className="muted">Registration is handled by the production API. Connect this form to POST /auth/register.</p>
        <form action="/api/register" method="post">
          <label>Email<br/><input name="email" type="email" required /></label>
          <br/><br/>
          <label>Phone<br/><input name="phone" /></label>
          <br/><br/>
          <label>Password<br/><input name="password" type="password" minLength={12} required /></label>
          <br/><br/>
          <button type="submit">Create account</button>
        </form>
        <p className="muted">Minimum password length: 12 characters.</p>
      </div>
    </main>
  );
}
