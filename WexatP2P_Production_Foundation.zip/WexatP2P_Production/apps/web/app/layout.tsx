import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "WexatP2P — Trade Direct. Trade Secure.",
  description: "ETB/USD peer-to-peer marketplace"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
