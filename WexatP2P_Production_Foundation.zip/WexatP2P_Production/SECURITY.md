# WexatP2P Security Rules

- Never store plaintext passwords.
- Never trust client-side KYC status, balances, rates or trade status.
- All money movement must be server-side and idempotent.
- Every payment webhook must be authenticated/verified by the provider.
- Ledger entries are append-only; corrections use compensating entries.
- Never release escrow based only on a browser button.
- KYC documents must live in private encrypted storage, not GitHub/public object storage.
- Use least-privilege database credentials.
- Use secure cookies in production.
- Enable HTTPS/HSTS.
- Add WAF/rate limiting and bot protection.
- Log security events without storing secrets.
- Separate support, compliance and super-admin permissions.
- Back up PostgreSQL and test restore procedures.
- Conduct an independent penetration test before handling real customer funds.
