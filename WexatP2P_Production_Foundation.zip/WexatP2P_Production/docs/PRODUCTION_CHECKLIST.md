# Production Launch Checklist

## Legal / regulatory
- [ ] Confirm WexatP2P's exact licensed/authorized operating model in Ethiopia.
- [ ] Confirm whether the business is an FX dealer, payment service, marketplace/technology provider, or operates through a licensed partner.
- [ ] Execute agreements with authorized payment/settlement providers.
- [ ] Compliance program approved: KYC/AML, sanctions screening, transaction monitoring, record retention.
- [ ] Terms, privacy policy, dispute/refund policy and customer disclosures reviewed by Ethiopian counsel.

## Identity
- [ ] Select real KYC provider.
- [ ] Implement document upload to private storage.
- [ ] Implement liveness/selfie verification.
- [ ] Provider webhook verification.
- [ ] Manual compliance review queue.

## Money movement
- [ ] Select authorized bank/payment provider.
- [ ] Implement payment initiation.
- [ ] Implement signed webhooks.
- [ ] Reconciliation jobs.
- [ ] Idempotency keys.
- [ ] Settlement confirmation.
- [ ] Failed/reversed payment handling.
- [ ] Daily reconciliation report.

## Security
- [ ] Production secret manager.
- [ ] HTTPS/HSTS.
- [ ] WAF/rate limiting.
- [ ] 2FA.
- [ ] Session/device management.
- [ ] Admin RBAC.
- [ ] Immutable audit logging.
- [ ] Backups + restore drill.
- [ ] Penetration test.

## Operations
- [ ] Monitoring and alerting.
- [ ] Error tracking.
- [ ] Customer support.
- [ ] Dispute/SLA process.
- [ ] Incident response.
- [ ] Fraud/risk rules.
