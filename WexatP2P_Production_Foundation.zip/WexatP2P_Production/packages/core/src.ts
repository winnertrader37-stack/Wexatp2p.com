import { z } from "zod";

export const registerSchema = z.object({
  email: z.string().email(),
  phone: z.string().min(7).max(30).optional(),
  password: z.string().min(12).max(128)
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

export const createOfferSchema = z.object({
  side: z.enum(["BUY_USD", "SELL_USD"]),
  rateEtbPerUsd: z.number().positive(),
  availableUsd: z.number().positive(),
  minUsd: z.number().positive(),
  maxUsd: z.number().positive(),
  paymentMethods: z.array(z.string()).min(1)
}).refine(v => v.minUsd <= v.maxUsd && v.maxUsd <= v.availableUsd, {
  message: "Invalid offer limits"
});

export const createTradeSchema = z.object({
  offerId: z.string().min(1),
  usdAmount: z.number().positive()
});

export const reportPaymentSchema = z.object({
  paymentId: z.string().min(1),
  providerReference: z.string().min(1)
});
